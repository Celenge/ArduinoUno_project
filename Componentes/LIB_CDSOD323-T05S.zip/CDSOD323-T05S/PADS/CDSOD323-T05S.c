*PADS-LIBRARY-SCH-DECALS-V9*

CDSOD323-T05S 0     0     100 10 100 10 4 4 0 2 8
TIMESTAMP 2017.10.19.15.22.37
"Default Font"
"Default Font"
400   350   0 0 100 10 "Default Font"
REF-DES
400   250   0 0 100 10 "Default Font"
PART-TYPE
400   -200  0 0 100 10 "Default Font"
*
400   -300  0 0 100 10 "Default Font"
*
CLOSED 4 10 0 -1
200   0    
400   100  
400   -100 
200   0    
OPEN   2 10 0 -1
200   -80  
240   -100 
OPEN   2 10 0 -1
200   -80  
200   80   
OPEN   2 10 0 -1
160   100  
200   80   
T0     0     0 0 0     20    0 0 0     -20   0 32 PIN
P-520  0     0 2 -80   0     0 2 0
T600   0     0 2 0     20    0 0 0     -20   0 32 PIN
P-520  0     0 2 -80   0     0 2 0

*END*
